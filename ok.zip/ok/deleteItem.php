<?php
include('fct/item.php');
include('fct/request.php');
include('config/app.php');

   #tODO à supprimer 
   $items= getItems();
   $id= get('item');
   
   unset($items[$id]);
   saveItems($items);
    
   header('Location:index.php');