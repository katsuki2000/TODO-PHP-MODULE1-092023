<?php
const APP_NAME = 'TODO list';
const FILE_NAME='items.txt';